'use strict';
// MOOD:ON — zero-dependency offline music curator. Song links open YouTube search; no audio is bundled.
const SETTINGS = {
  mood: [['😊','행복함'],['💗','설렘'],['🌧️','우울함'],['😮‍💨','스트레스'],['🫠','지루함'],['🍵','편안함'],['🌙','외로움'],['⚡','신남'],['🛋️','쉬고 싶음']],
  weather: [['☀️','맑음'],['☁️','흐림'],['🌧️','비'],['❄️','눈'],['🌞','더움'],['🧣','추움']],
  activity: [['📖','공부'],['🏃','운동'],['🌿','산책'],['🚗','드라이브'],['🚇','출퇴근·등하교'],['💌','데이트'],['🫧','휴식'],['🧳','여행'],['🌙','혼자만의 시간'],['🎉','파티·모임']],
  genres: [['','K-POP'],['','R&B'],['','힙합'],['','팝'],['','인디'],['','발라드'],['','EDM'],['','록'],['','재즈'],['','시티팝'],['','J-POP'],['','OST']],
  vibe: [['✨','잔잔한'],['💭','감성적인'],['🪄','몽환적인'],['🎈','신나는'],['🔥','강렬한'],['💘','로맨틱한'],['📼','레트로한'],['💎','세련된']],
  language: [['🇰🇷','한국어'],['🇺🇸','영어'],['🇯🇵','일본어'],['🌍','상관없음']],
  count: [['','3곡'],['','5곡'],['','10곡']]
};
const state = {mood:'',weather:'',activity:'',genres:[],vibe:'',tempo:105,language:'',count:'5곡',round:0,results:[],lastPage:'home'};
const tracks = [
// Each catalog item is curated locally, not AI-generated or fetched. BPM is an approximate recommendation index, not verified song metadata.
['Ditto','NewJeans','K-POP','한국어',105,'감성적인,몽환적인,레트로한','우울함,외로움,편안함','흐림,눈,추움','산책,혼자만의 시간,출퇴근·등하교'],
['Hype Boy','NewJeans','K-POP','한국어',122,'신나는,세련된','행복함,설렘,신남','맑음,더움','드라이브,여행,출퇴근·등하교'],
['Super Shy','NewJeans','K-POP','한국어',145,'신나는,세련된','설렘,행복함,신남','맑음,더움','운동,파티·모임'],
['LOVE DIVE','IVE','K-POP','한국어',118,'몽환적인,세련된','설렘,신남','맑음,흐림','드라이브,데이트'],
['After LIKE','IVE','K-POP','한국어',126,'신나는,레트로한','행복함,신남','맑음,더움','운동,파티·모임'],
['Drama','aespa','K-POP','한국어',140,'강렬한,세련된','신남,스트레스','흐림,추움','운동,파티·모임'],
['Supernova','aespa','K-POP','한국어',125,'강렬한,신나는','신남,지루함','맑음,더움','운동,파티·모임'],
['Magnetic','ILLIT','K-POP','한국어',126,'신나는,몽환적인','설렘,행복함','맑음,더움','산책,데이트'],
['ANTIFRAGILE','LE SSERAFIM','K-POP','한국어',105,'강렬한,신나는','스트레스,신남','맑음,더움','운동,파티·모임'],
['Love 119','RIIZE','K-POP','한국어',100,'로맨틱한,감성적인','설렘,편안함','눈,추움','데이트,산책'],
['밤편지','아이유','발라드','한국어',78,'잔잔한,감성적인,로맨틱한','우울함,외로움,쉬고 싶음','비,눈,추움','휴식,혼자만의 시간,공부'],
['Blueming','아이유','K-POP','한국어',110,'신나는,로맨틱한','설렘,행복함','맑음','산책,데이트'],
['너의 의미','아이유','인디','한국어',90,'잔잔한,레트로한','편안함,쉬고 싶음','맑음,흐림','휴식,산책'],
['사건의 지평선','윤하','록','한국어',121,'감성적인,신나는','우울함,행복함','맑음,흐림','드라이브,여행'],
['여행','볼빨간사춘기','인디','한국어',120,'신나는,감성적인','행복함,지루함','맑음,더움','여행,산책'],
['우주를 줄게','볼빨간사춘기','인디','한국어',95,'몽환적인,로맨틱한','설렘,편안함','맑음,눈','데이트,산책'],
['instagram','DEAN','R&B','한국어',86,'감성적인,세련된','외로움,우울함,쉬고 싶음','비,흐림','혼자만의 시간,휴식'],
['D (half moon)','DEAN','R&B','한국어',90,'몽환적인,감성적인','외로움,설렘','비,추움','혼자만의 시간,데이트'],
['주지마','로꼬, 화사','R&B','한국어',95,'세련된,로맨틱한','설렘,편안함','흐림,비','데이트,드라이브'],
['우리서로사랑하지는말자','기리보이','힙합','한국어',92,'감성적인,잔잔한','우울함,외로움','비,추움','혼자만의 시간,산책'],
['Dynamite','BTS','K-POP','영어',114,'신나는,레트로한','행복함,신남','맑음,더움','운동,파티·모임'],
['Butter','BTS','K-POP','영어',110,'세련된,신나는','행복함,신남','맑음,더움','드라이브,파티·모임'],
['Blinding Lights','The Weeknd','팝','영어',171,'레트로한,신나는','신남,지루함','맑음,추움','드라이브,운동'],
['Save Your Tears','The Weeknd','팝','영어',118,'레트로한,감성적인','우울함,외로움','흐림,비','드라이브,혼자만의 시간'],
['Die For You','The Weeknd','R&B','영어',80,'로맨틱한,감성적인','설렘,외로움','비,추움','데이트,혼자만의 시간'],
['golden hour','JVKE','팝','영어',94,'로맨틱한,몽환적인','설렘,편안함','맑음,눈','데이트,산책'],
['Until I Found You','Stephen Sanchez','팝','영어',101,'로맨틱한,레트로한','설렘,편안함','눈,추움','데이트,휴식'],
['As It Was','Harry Styles','팝','영어',174,'신나는,감성적인','지루함,행복함','맑음,흐림','드라이브,산책'],
['Levitating','Dua Lipa','팝','영어',103,'신나는,세련된','신남,행복함','맑음,더움','운동,파티·모임'],
['good 4 u','Olivia Rodrigo','록','영어',167,'강렬한,신나는','스트레스,신남','맑음,흐림','운동,드라이브'],
['drivers license','Olivia Rodrigo','발라드','영어',72,'감성적인,잔잔한','우울함,외로움','비,눈','혼자만의 시간,휴식'],
['Cruel Summer','Taylor Swift','팝','영어',170,'신나는,로맨틱한','설렘,신남','맑음,더움','여행,드라이브'],
['Style','Taylor Swift','팝','영어',95,'세련된,레트로한','설렘,행복함','맑음,흐림','드라이브,데이트'],
['Sunflower','Post Malone, Swae Lee','힙합','영어',90,'잔잔한,세련된','편안함,행복함','맑음,더움','산책,드라이브'],
['Location','Khalid','R&B','영어',80,'몽환적인,세련된','편안함,설렘','흐림,비','휴식,데이트'],
['Best Part','Daniel Caesar, H.E.R.','R&B','영어',78,'로맨틱한,잔잔한','설렘,편안함','비,눈','데이트,휴식'],
['Get Lucky','Daft Punk, Pharrell Williams','EDM','영어',116,'레트로한,신나는','행복함,신남','맑음,더움','파티·모임,드라이브'],
['One More Time','Daft Punk','EDM','영어',123,'신나는,레트로한','신남,지루함','맑음,더움','파티·모임,운동'],
['Fly Me to the Moon','Frank Sinatra','재즈','영어',119,'레트로한,로맨틱한','편안함,설렘','맑음,눈','데이트,휴식'],
['L-O-V-E','Nat King Cole','재즈','영어',102,'로맨틱한,레트로한','행복함,설렘','맑음','데이트,휴식'],
['Plastic Love','Mariya Takeuchi','시티팝','일본어',103,'레트로한,세련된','편안함,외로움','흐림,비','드라이브,혼자만의 시간'],
['Stay With Me','Miki Matsubara','시티팝','일본어',108,'레트로한,감성적인','외로움,설렘','비,추움','드라이브,혼자만의 시간'],
['夜に駆ける','YOASOBI','J-POP','일본어',130,'신나는,감성적인','지루함,신남','맑음,흐림','드라이브,산책'],
['アイドル','YOASOBI','J-POP','일본어',166,'신나는,강렬한','신남,지루함','맑음,더움','운동,파티·모임'],
['Lemon','Kenshi Yonezu','J-POP','일본어',87,'감성적인,잔잔한','우울함,외로움','비,눈','휴식,혼자만의 시간'],
['なんでもないや','RADWIMPS','OST','일본어',89,'몽환적인,감성적인','설렘,외로움','비,눈','산책,혼자만의 시간'],
['City of Stars','Ryan Gosling, Emma Stone','OST','영어',84,'로맨틱한,잔잔한','설렘,편안함','흐림,눈','데이트,휴식'],
['A Thousand Years','Christina Perri','OST','영어',70,'로맨틱한,감성적인','설렘,외로움','눈,비','데이트,휴식'],
['봄날','BTS','K-POP','한국어',108,'감성적인,잔잔한','외로움,우울함','흐림,추움','산책,혼자만의 시간'],
['Attention','NewJeans','K-POP','한국어',105,'세련된,잔잔한','설렘,행복함','맑음,더움','산책,데이트']
].map((x,id)=>({id,title:x[0],artist:x[1],genre:x[2],language:x[3],bpm:x[4],vibes:x[5].split(','),moods:x[6].split(','),weathers:x[7].split(','),activities:x[8].split(',')}));
const $ = id => document.getElementById(id);
const pages=['home','form','results','saved'];
const moodMessages={
 '행복함':'좋은 일이 있었나 봐! 지금 이 반짝이는 기분을 좀 더 오래 즐길 수 있도록 골라봤어.',
 '설렘':'심장이 살짝 빠르게 뛰는 날이지? 오늘의 설렘에 사운드트랙을 더해볼게.',
 '우울함':'오늘은 마음이 조금 무거울 수 있지. 억지로 밝아지지 않아도 괜찮아. 음악이 옆에 있을게.',
 '스트레스':'복잡했던 마음 잠깐 내려놓자. 가볍게 털어내기 좋은 곡들로 준비했어.',
 '지루함':'평범한 하루도 플레이 버튼 하나로 달라질 수 있어. 새로운 장면을 틀어볼까?',
 '편안함':'지금의 여유를 천천히 음미해봐. 조용하게 이어지는 멜로디를 준비했어.',
 '외로움':'혼자 있는 시간에도 좋은 음악은 꽤 근사한 친구가 되어주지. 같이 들어볼래?',
 '신남':'오늘 텐션 최고인데? 이 에너지 그대로 이어갈 음악을 준비했어!',
 '쉬고 싶음':'오늘은 아무것도 서두르지 말자. 마음을 편안하게 해 줄 음악으로 채워볼게.'
};
const moodTitles={'행복함':'좋은 하루는 더 크게','설렘':'마음이 먼저 뛰는 순간','우울함':'괜찮지 않아도 괜찮은 밤','스트레스':'생각은 잠시 볼륨 다운','지루함':'일상에 작은 반전','편안함':'느리게 흘러가는 오후','외로움':'혼자여도 따뜻한 시간','신남':'볼륨을 높여도 좋은 오늘','쉬고 싶음':'아무것도 하지 않을 자유'};
const activityPhrases={'공부':'집중하고 싶은 지금','운동':'움직임에 에너지를 더할 때','산책':'발걸음에 리듬을 실을 때','드라이브':'차창 밖 풍경과 함께','출퇴근·등하교':'익숙한 길을 새로운 장면으로','데이트':'함께하는 순간에','휴식':'느긋하게 쉬는 시간에','여행':'낯선 풍경을 만날 때','혼자만의 시간':'내 마음에 귀 기울일 때','파티·모임':'함께 즐거움을 나눌 때'};
const palette=[['#8f82d8','#eea9c8'],['#6c95c5','#9ad1d2'],['#b98aaf','#f1c6b1'],['#a7a0cd','#e6cdb0'],['#749fa1','#ded1a8'],['#b87dcb','#8e7ae5'],['#d9a3bc','#f2d6bf'],['#6e86c3','#ceacec']];
let savedIds=new Set(); let toastHandle;
try{const saved=JSON.parse(localStorage.getItem('moodon_saved_v2')||'[]');if(Array.isArray(saved))savedIds=new Set(saved.filter(Number.isInteger));}catch(e){savedIds=new Set();}
function storeSaved(){try{localStorage.setItem('moodon_saved_v2',JSON.stringify([...savedIds]));}catch(e){notify('브라우저 저장이 제한되어 있어. 이 창에서는 계속 사용할 수 있어.');}}
function updateSavedCount(){$('saved-count').textContent=String(savedIds.size);}
function notify(msg){const t=$('toast');t.textContent=msg;t.classList.add('visible');clearTimeout(toastHandle);toastHandle=setTimeout(()=>t.classList.remove('visible'),2600);}
function showPage(id){pages.forEach(p=>{const e=$('page-'+p);e.hidden=p!==id;e.classList.toggle('active',p===id);});state.lastPage=id;window.scrollTo({top:0,behavior:'instant'});}
function createChoices(name,container,values,multi=false){const el=$(container);values.forEach(([emoji,label])=>{const b=document.createElement('button');b.type='button';b.className='option';b.dataset.value=label;b.setAttribute('aria-pressed',String(multi?state[name].includes(label):state[name]===label));if(emoji){const e=document.createElement('span');e.className='emoji';e.textContent=emoji;b.append(e);}b.append(document.createTextNode(label));b.addEventListener('click',()=>{if(multi){if(state[name].includes(label))state[name]=state[name].filter(g=>g!==label);else state[name].push(label);}else{state[name]=label;}el.querySelectorAll('.option').forEach(node=>{const active=multi?state[name].includes(node.dataset.value):state[name]===node.dataset.value;node.classList.toggle('selected',active);node.setAttribute('aria-pressed',String(active));});const box=document.querySelector(`[data-field="${name}"]`);if(box)box.classList.remove('invalid');$('validation-message').textContent='';});el.append(b);});if(!multi&&state[name]){const b=[...el.children].find(x=>x.dataset.value===state[name]);if(b)b.classList.add('selected');}}
function initialise(){createChoices('mood','mood-options',SETTINGS.mood);createChoices('weather','weather-options',SETTINGS.weather);createChoices('activity','activity-options',SETTINGS.activity);createChoices('genres','genre-options',SETTINGS.genres,true);createChoices('vibe','vibe-options',SETTINGS.vibe);createChoices('language','language-options',SETTINGS.language);createChoices('count','count-options',SETTINGS.count);const tempo=$('tempo');tempo.addEventListener('input',()=>{state.tempo=Number(tempo.value);$('tempo-value').textContent=tempo.value;$('tempo-description').textContent=state.tempo<90?'느긋하고 부드럽게':state.tempo<125?'적당히 리드미컬':'빠르고 에너지 있게';});$('home-logo').addEventListener('click',()=>showPage('home'));$('start-button').addEventListener('click',()=>showPage('form'));$('back-home').addEventListener('click',()=>showPage('home'));$('back-form').addEventListener('click',()=>showPage('form'));$('saved-nav').addEventListener('click',()=>{const active=pages.find(p=>!$('page-'+p).hidden);if(active!=='saved')state.returnPage=active;renderSaved();showPage('saved');});$('back-from-saved').addEventListener('click',()=>showPage(state.returnPage||'home'));$('mood-form').addEventListener('submit',onSubmit);$('reroll-button').addEventListener('click',()=>{state.round++;recommend();});$('reset-button').addEventListener('click',()=>{state.round=0;showPage('form');});$('copy-playlist').addEventListener('click',copyPlaylist);updateSavedCount();showPage('home');}
function validate(){const required=[['mood','기분'],['weather','날씨'],['activity','활동'],['genres','선호 장르'],['vibe','음악 분위기'],['language','음악 언어']];const missing=required.filter(([key])=>!state[key]||(Array.isArray(state[key])&&!state[key].length));document.querySelectorAll('.field-card').forEach(x=>x.classList.remove('invalid'));if(missing.length){for(const [key] of missing){const node=document.querySelector(`[data-field="${key}"]`);if(node)node.classList.add('invalid');}const first=document.querySelector(`[data-field="${missing[0][0]}"]`);$('validation-message').textContent='선택이 필요해: '+missing.map(x=>x[1]).join(', ');if(first)first.scrollIntoView({behavior:'smooth',block:'center'});notify(missing[0][1]+'부터 선택해 줘!');return false;}return true;}
function onSubmit(event){event.preventDefault();if(!validate())return;state.round=0;recommend();}
function score(t){let v=0; if(state.genres.includes(t.genre))v+=11;else v-=4;if(t.vibes.includes(state.vibe))v+=10;if(t.moods.includes(state.mood))v+=8;if(t.weathers.includes(state.weather))v+=5;if(t.activities.includes(state.activity))v+=8;if(state.language==='상관없음'||t.language===state.language)v+=state.language==='상관없음'?1:11;else v-=18;v+=Math.max(0,8-Math.abs(state.tempo-t.bpm)/12);return v;}
function orderVariation(t){return ((t.id*37+state.round*23+11)%53)/10;}
function recommend(){const count=parseInt(state.count,10);const order=tracks.map(t=>({t,score:score(t)+orderVariation(t)})).sort((a,b)=>b.score-a.score);state.results=order.slice(0,count).map(x=>x.t);$('results-comment').textContent=moodMessages[state.mood]+' '+activityPhrases[state.activity]+' 어울리는 곡으로 모았어.';$('playlist-title').textContent=moodTitles[state.mood];$('playlist-subtitle').textContent=`${state.results.length}곡 · ${state.vibe} 분위기 · ${state.activity}`;const tags=$('selected-tags');tags.replaceChildren();[state.mood,state.weather,state.activity,state.vibe,...state.genres].forEach(x=>{const e=document.createElement('span');e.textContent=x;tags.append(e);});renderList($('song-list'),state.results);showPage('results');}
function reasonFor(t){const messages=[];if(t.moods.includes(state.mood))messages.push(`${state.mood} 기분에 잘 스며드는 멜로디`);if(t.vibes.includes(state.vibe))messages.push(`${state.vibe} 무드`);if(t.activities.includes(state.activity))messages.push(`${state.activity}할 때 자연스럽게 어울리는 리듬`);if(t.weathers.includes(state.weather))messages.push(`${state.weather} 날씨와 닮은 분위기`);if(state.genres.includes(t.genre))messages.push(`좋아하는 ${t.genre} 장르`);return (messages.length?messages.slice(0,2).join('과 ')+'가 매력적이야.':`${t.genre}의 매력을 새롭게 느낄 수 있는 곡이야.`)+' 한 번 들어봐!';}
function renderList(parent,items,isSaved=false){parent.replaceChildren();if(!items.length){const wrap=document.createElement('div');wrap.className='empty-state';wrap.innerHTML='<div class="empty-icon">♡</div><h3>아직 저장한 노래가 없어</h3><p>추천 결과에서 하트를 누르면 여기에 모여!</p>';parent.append(wrap);return;}items.forEach((t,i)=>{const wrap=document.createElement('article');wrap.className='song-card';const art=document.createElement('div');art.className='song-art';const colors=palette[t.id%palette.length];art.style.setProperty('--c1',colors[0]);art.style.setProperty('--c2',colors[1]);art.textContent='♫';const info=document.createElement('div');info.className='song-info';const title=document.createElement('h4');title.textContent=`${isSaved?'':String(i+1).padStart(2,'0')+'  '}${t.title}`;const artist=document.createElement('p');artist.className='artist';artist.textContent=t.artist;const reason=document.createElement('p');reason.className='reason';reason.textContent=isSaved?`${t.genre} · ${t.language}`:reasonFor(t);const tags=document.createElement('div');tags.className='mini-tags';[t.genre,...t.vibes.slice(0,1)].forEach(text=>{const span=document.createElement('span');span.textContent=text;tags.append(span);});info.append(title,artist,reason,tags);const actions=document.createElement('div');actions.className='song-actions';const heart=document.createElement('button');heart.type='button';heart.className='heart-button'+(savedIds.has(t.id)?' is-saved':'');heart.textContent=savedIds.has(t.id)?'♥':'♡';heart.setAttribute('aria-label',savedIds.has(t.id)?`${t.title} 저장 취소`:`${t.title} 저장하기`);heart.addEventListener('click',()=>{if(savedIds.has(t.id)){savedIds.delete(t.id);notify('저장 목록에서 제외했어.');}else{savedIds.add(t.id);notify('마음에 드는 곡을 저장했어!');}storeSaved();updateSavedCount();renderList(parent,items,isSaved);if(isSaved)renderSaved();});const link=document.createElement('a');link.className='listen-link';link.href='https://www.youtube.com/results?search_query='+encodeURIComponent(`${t.artist} ${t.title} official audio`);link.target='_blank';link.rel='noopener noreferrer';link.textContent='듣기 ↗';link.setAttribute('aria-label',`${t.title} 유튜브에서 검색`);actions.append(heart,link);wrap.append(art,info,actions);parent.append(wrap);});}
function renderSaved(){renderList($('saved-song-list'),tracks.filter(t=>savedIds.has(t.id)),true);}
async function copyPlaylist(){if(!state.results.length)return;const text=[`MOOD:ON — ${moodTitles[state.mood]}`,`기분 ${state.mood} · 날씨 ${state.weather} · 활동 ${state.activity}`,...state.results.map((t,i)=>`${i+1}. ${t.title} — ${t.artist}`)].join('\n');try{await navigator.clipboard.writeText(text);notify('플레이리스트가 복사되었어!');}catch(e){const box=document.createElement('textarea');box.value=text;box.style.position='fixed';box.style.opacity='0';document.body.append(box);box.select();try{const ok=document.execCommand('copy');notify(ok?'플레이리스트가 복사되었어!':'복사할 수 없어. 브라우저 권한을 확인해 줘.');}catch(error){notify('복사 기능을 사용할 수 없어.');}box.remove();}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initialise);else initialise();
